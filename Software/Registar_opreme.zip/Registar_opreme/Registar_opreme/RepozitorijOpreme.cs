﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using dll;

namespace Registar_opreme
{
    public class RepozitorijOpreme
    {

        public static List<Oprema> DohvatiOpremu()
        {
            List<Oprema> oprema = new List<Oprema>();
            string sql = "SELECT * FROM Oprema";
            DB.OpenConnection();
            var reader = DB.GetDataReader(sql);
            while (reader.Read())
            {
                Oprema oprema1 = CreateObject(reader);
                oprema.Add(oprema1);
            }
            reader.Close();
            DB.CloseConnection();

            return oprema;
        }

        public static List<Oprema> DohvatiOpremu(string trazi)
        {
            List<Oprema> oprema = new List<Oprema>();
            string sql = $"SELECT * FROM Oprema WHERE nazivOpreme like '%{trazi}%'";
            DB.OpenConnection();
            var reader = DB.GetDataReader(sql);
            while (reader.Read())
            {
                Oprema oprema1 = CreateObject(reader);
                oprema.Add(oprema1);
            }
            reader.Close();
            DB.CloseConnection();

            return oprema;
        }

        public static void DodajOpremu(Oprema oprema)
        {
            string sql = $"INSERT INTO Oprema (nazivOpreme, vrstaOpreme, kolicinaJediniceOpreme, dostupnoOpreme) VALUES ('{oprema.nazivOpreme}', '{oprema.vrstaOpreme}', {oprema.kolicinaJediniceOpreme}, {oprema.dostupnoOpreme})";
            DB.OpenConnection();
            DB.ExecuteCommand(sql);
            DB.CloseConnection();
        }

        public static void UrediOpremu(Oprema oprema)
        {
            string sql = $"UPDATE Oprema SET nazivOpreme = '{oprema.nazivOpreme}', vrstaOpreme = '{oprema.vrstaOpreme}', kolicinaJediniceOpreme = {oprema.kolicinaJediniceOpreme}, dostupnoOpreme = {oprema.dostupnoOpreme} WHERE ID_oprema = {oprema.ID_oprema}";
            DB.OpenConnection();
            DB.ExecuteCommand(sql);
            DB.CloseConnection();
        }

        private static Oprema CreateObject(SqlDataReader reader)
        {
            int id = int.Parse(reader["ID_oprema"].ToString());
            string nazOprema = reader["nazivOpreme"].ToString();
            string vrOprema = reader["vrstaOpreme"].ToString();
            int kol = int.Parse(reader["kolicinaJediniceOpreme"].ToString());
            int dostupno = int.Parse(reader["dostupnoOpreme"].ToString());
            var oprema = new Oprema
            {
                ID_oprema = id,
                nazivOpreme = nazOprema,
                vrstaOpreme = vrOprema,
                dostupnoOpreme = dostupno,
                kolicinaJediniceOpreme = kol
            };
            return oprema;
        }

        public static void ObrisiOpremu(Oprema oprema)
        {
            string sql = $"DELETE FROM Oprema WHERE ID_oprema = {oprema.ID_oprema}";
            DB.OpenConnection();
            DB.ExecuteCommand(sql);
            DB.CloseConnection();
        }
    }
}
